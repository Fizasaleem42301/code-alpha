const display = document.getElementById('display');
let currentInput = '';
let operator = null;
let previousInput = '';

document.querySelectorAll('.button').forEach(button => {
    button.addEventListener('click', () => {
        const type = button.getAttribute('data-type');
        const value = button.textContent;

        if (type === 'number' || type === 'decimal') {
            handleNumber(value);
        } else if (type === 'operator') {
            handleOperator(value);
        }
    });
});

function handleNumber(value) {
    if (value === '.' && currentInput.includes('.')) return;
    currentInput += value;
    updateDisplay(currentInput);
}

function handleOperator(value) {
    if (value === '=') {
        calculateResult();
    } else {
        if (currentInput) {
            if (operator) calculateResult();
            previousInput = currentInput;
            currentInput = '';
        }
        operator = value;
    }
}

function calculateResult() {
    if (!previousInput || !currentInput) return;
    let result;
    const prev = parseFloat(previousInput);
    const curr = parseFloat(currentInput);

    switch (operator) {
        case '+':
            result = prev + curr;
            break;
        case '-':
            result = prev - curr;
            break;
        case '*':
            result = prev * curr;
            break;
        case '/':
            result = prev / curr;
            break;
    }

    currentInput = result.toString();
    operator = null;
    previousInput = '';
    updateDisplay(currentInput);
}

function updateDisplay(value) {
    display.textContent = value;
}
const audio = document.getElementById('audio');
const playButton = document.getElementById('play');
const prevButton = document.getElementById('prev');
const nextButton = document.getElementById('next');
const title = document.getElementById('title');
const artist = document.getElementById('artist');

const tracks = [
    {
        title: 'song 1',
        artist: 'Artist One',
        src: 'song 1.mp3'
    },
    {
        title: 'song Two',
        artist: 'Artist Two',
        src: 'song 2.mp3'
    },
    {
        title: 'song 3',
        artist: 'Artist Three',
        src: 'song 3.mp3'
    }
];

let currentTrackIndex = 0;

function loadTrack(index) {
    const track = tracks[index];
    audio.src = track.src;
    title.textContent = track.title;
    artist.textContent = track.artist;
}

function playPause() {
    if (audio.paused) {
        audio.play();
        playButton.textContent = 'Pause';
    } else {
        audio.pause();
        playButton.textContent = 'Play';
    }
}

function prevTrack() {
    currentTrackIndex = (currentTrackIndex - 1 + tracks.length) % tracks.length;
    loadTrack(currentTrackIndex);
    audio.play();
    playButton.textContent = 'Pause';
}

function nextTrack() {
    currentTrackIndex = (currentTrackIndex + 1) % tracks.length;
    loadTrack(currentTrackIndex);
    audio.play();
    playButton.textContent = 'Pause';
}

playButton.addEventListener('click', playPause);
prevButton.addEventListener('click', prevTrack);
nextButton.addEventListener('click', nextTrack);

// Load the first track initially
loadTrack(currentTrackIndex);
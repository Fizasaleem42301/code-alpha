const images = [
    'image 1.jfif',
    'image 2.jfif',
    'image 3.jfif',
  ];
  
  let currentIndex = 0;
  
  const currentImage = document.getElementById('current-image');
  const thumbnails = document.querySelectorAll('.thumbnail');
  const prevBtn = document.getElementById('prev-btn');
  const nextBtn = document.getElementById('next-btn');
  
  function showImage(index) {
    currentImage.src = images[index];
    currentIndex = index;
  }
  
  thumbnails.forEach((thumbnail, index) => {
    thumbnail.addEventListener('click', () => showImage(index));
  });
  
  prevBtn.addEventListener('click', () => {
    currentIndex = (currentIndex - 1 + images.length) % images.length;
    showImage(currentIndex);
  });
  
  nextBtn.addEventListener('click', () => {
    currentIndex = (currentIndex + 1) % images.length;
    showImage(currentIndex);
  });
  
  // Initial display
  showImage(currentIndex);